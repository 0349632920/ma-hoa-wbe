@echo off
echo Đang tải Virus...
git clone https://github.com/0349632920/Download-tool.git
pause